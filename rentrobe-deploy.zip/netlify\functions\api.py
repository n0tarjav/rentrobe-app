import json
import os
import sys
from pathlib import Path

# Add the project root to the Python path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

# Set up database path for Netlify
# Database will be in the same directory as the function
db_path = os.path.join(os.path.dirname(__file__), 'wearhouse.db')
os.environ['DATABASE_URL'] = f'sqlite:///{db_path}'

# Set secret key for Netlify
os.environ['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'wearhouse-netlify-secret-key-change-in-production')

# Set session configuration for Netlify
os.environ['SESSION_COOKIE_SECURE'] = 'True'  # Netlify uses HTTPS
os.environ['SESSION_COOKIE_HTTPONLY'] = 'True'
os.environ['SESSION_COOKIE_SAMESITE'] = 'None'  # Required for cross-origin requests in Netlify
os.environ['SESSION_COOKIE_DOMAIN'] = ''  # Don't set domain for Netlify

# Import Flask app
from app import app, db, init_db

def handler(event, context):
    """
    Netlify serverless function handler for Flask API
    """
    print(f"Function called with event: {event}")
    print(f"Context: {context}")
    
    try:
        # Parse the event
        path = event.get('path', '')
        http_method = event.get('httpMethod', 'GET')
        headers = event.get('headers', {})
        body = event.get('body', '')
        query_string = event.get('queryStringParameters', {}) or {}
        
        # Convert headers to lowercase for Flask compatibility
        headers = {k.lower(): v for k, v in headers.items()}
        
        # Remove /api prefix from path for Flask routing
        if path.startswith('/api'):
            path = path[4:]  # Remove '/api' prefix
        if not path:
            path = '/'
        
        # Handle query string parameters
        if query_string:
            query_string = '&'.join([f"{k}={v}" for k, v in query_string.items()])
        else:
            query_string = ''
        
        # Handle CORS preflight
        if http_method == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization, Cookie, X-Requested-With',
                    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                    'Access-Control-Allow-Credentials': 'true',
                    'Access-Control-Max-Age': '86400'
                },
                'body': ''
            }
        
        # Initialize database if needed
        with app.app_context():
            try:
                # Always try to initialize database to ensure demo user exists
                print(f"Initializing database at {db_path}")
                init_db()
                print(f"Database initialized successfully")
                
                # Check if demo user exists, create if not
                from app import User, bcrypt
                demo_user = User.query.filter_by(email='demo@wearhouse.com').first()
                if not demo_user:
                    print("Creating demo user...")
                    demo_user = User(
                        name='Demo User',
                        email='demo@wearhouse.com',
                        password_hash=bcrypt.generate_password_hash('password123').decode('utf-8'),
                        phone='+91 9876543210',
                        city='Mumbai',
                        address='123 Fashion Street, Mumbai',
                        is_verified=True
                    )
                    db.session.add(demo_user)
                    db.session.commit()
                    print("Demo user created successfully")
                else:
                    print("Demo user already exists")
                
                # Also create other demo users for testing
                arjav_user = User.query.filter_by(email='arjav@rentrobe.com').first()
                if not arjav_user:
                    print("Creating Arjav user...")
                    arjav_user = User(
                        name='Arjav',
                        email='arjav@rentrobe.com',
                        password_hash=bcrypt.generate_password_hash('arjav0302').decode('utf-8'),
                        phone='+91 8319337033',
                        city='Bhilai',
                        address='Bhilai, Chhattisgarh',
                        is_verified=True
                    )
                    db.session.add(arjav_user)
                    db.session.commit()
                    print("Arjav user created successfully")
                
                # Test database connection
                total_users = User.query.count()
                print(f"Total users in database: {total_users}")
                    
            except Exception as db_error:
                print(f"Database init error: {str(db_error)}")
                import traceback
                traceback.print_exc()
                # Continue anyway for testing
        
        # Create a mock request context
        print(f"Handling request: {http_method} {path}")
        print(f"Body: {body}")
        print(f"Headers: {headers}")
        print(f"Query string: {query_string}")
        
        # Handle cookies for session management
        cookies = {}
        if 'cookie' in headers:
            cookie_header = headers['cookie']
            for cookie in cookie_header.split(';'):
                if '=' in cookie:
                    key, value = cookie.strip().split('=', 1)
                    cookies[key] = value
        
        # Debug logging for authentication
        print(f"Cookies received: {cookies}")
        print(f"Session cookie present: {'session' in cookies}")
        
        with app.test_request_context(
            path=path,
            method=http_method,
            headers=headers,
            data=body,
            query_string=query_string,
            cookies=cookies
        ):
            # Handle the request
            response = app.full_dispatch_request()
            print(f"Response status: {response.status_code}")
            
            # Extract response data
            response_data = response.get_data(as_text=True)
            status_code = response.status_code
            response_headers = dict(response.headers)
            
            # Handle JSON responses
            if response_headers.get('Content-Type', '').startswith('application/json'):
                try:
                    response_data = json.loads(response_data)
                except json.JSONDecodeError:
                    pass
            
            # Get response headers from Flask response
            response_headers = dict(response.headers)
            
            # Add CORS headers
            cors_headers = {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization, Cookie, X-Requested-With',
                'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
                'Access-Control-Allow-Credentials': 'true'
            }
            
            # Merge Flask headers with CORS headers
            final_headers = {**cors_headers, **response_headers}
            
            # Handle Set-Cookie headers for session management
            set_cookie_headers = []
            for header_name, header_value in response.headers:
                if header_name.lower() == 'set-cookie':
                    set_cookie_headers.append(header_value)
            
            if set_cookie_headers:
                final_headers['Set-Cookie'] = set_cookie_headers
                print(f"Setting cookies: {set_cookie_headers}")
            
            return {
                'statusCode': status_code,
                'headers': final_headers,
                'body': json.dumps(response_data)
            }
    
    except Exception as e:
        print(f"Error in API handler: {str(e)}")
        import traceback
        traceback.print_exc()
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': f'Internal server error: {str(e)}'})
        }
